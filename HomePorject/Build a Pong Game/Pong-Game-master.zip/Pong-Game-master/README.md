# Pong Game
A pong game made using the Turtle Library in Python.

## Getting Started
* Run the command "python main.py"
* Make sure you run the command in the same directory as the one where you cloned the repo in order for the sound to play
## Acknowledgments
* Christian Thompson (FreeCodeCamp)  [Tutorial](https://www.youtube.com/watch?v=C6jJg9Zan7w)

